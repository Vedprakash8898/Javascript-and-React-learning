import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import ShowProduct from "./components/ShowProduct.js";

const Home = () => {


    return (
        <div>
            <h1 style={{textAlign:'center', "color":"red","background":"green"}}>Welcome to Our E-Commerce Website</h1>
            <ShowProduct />
        </div>
            

            
    );
}

export default Home;