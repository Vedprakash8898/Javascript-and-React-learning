import React from 'react'

function AddToCart() {
  return (
    <div>AddToCart</div>
  )
}

export default AddToCart