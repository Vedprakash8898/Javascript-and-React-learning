import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';


export default function ShowProduct() {
    var [api,setApi]=useState([]);
    useEffect(()=>{
        fetch('https://fakestoreapi.com/products')
        .then(res=>res.json())
        .then(val=>{
            console.log(val);
            setApi(val)
        })
    },[]);

    const myfunc = (ev) =>{
        console.log(ev);
        ev.target.style.background = "green"


    }



  return (
    <Container>
        <h1 className='text-center'  style={{ "color":"pink"}}>Our Latest products</h1>
        <Row>
            {
                api.length>0 && api.map(obj=>
                    <Col  lg="3">
                        <Link to = {"/single-product/"+obj.id}>
                        <img  img src={obj.image} className="img-fluid" alt='img'/>
                        </Link>

                        <h2>
                        
                            
                            {obj.id}</h2>

                        <h2>{obj.price}</h2>

                        <p>{obj.title}</p>
                        <Link to = {"/add-cart/"+obj.id}>
                            <button>Add to Cart</button>
                        </Link>
                            

                    </Col>
                )
            }
        </Row>
    </Container>
  )
}
