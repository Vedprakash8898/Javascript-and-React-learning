import React, { useEffect ,useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import Button from 'react-bootstrap/Button';


function SinglePageProduct() {
    var [api,setApi] = useState({});

    var ans = useParams();
    console.log(ans);

    var id = ans['userid'];
    console.log(id);


    useEffect(() => {
        fetch(`https://fakestoreapi.com/products/${id}`)
        .then(res => res.json())
        .then(apivalue =>{
            console.log(apivalue)
            setApi(apivalue);
        })

    } , [])



  return (
    <div className='container'>
        <h1>Single Product Page </h1>
        <div className='row'>
            <div className='col-xl-6'>
                <img src={api.image} className="img-fluid" />

            </div>
            <div className='col-xl-6'>
                <h2>&#8377; {api.price}</h2>
                <h1>{api.title}</h1>
                {/* <h2> Rating : {api.rating.rate}</h2>
                <h2> Count : {api.rating.count}</h2> */}
                <p>{api.description}</p>
                <h2>{api.category}</h2>
                <Link to = {'/add-cart/'+api.id}>
                            
                <p><Button variant="warning">Add to cart</Button></p>
            </Link>

            </div>

        </div>
    </div>

  )
}

export default SinglePageProduct